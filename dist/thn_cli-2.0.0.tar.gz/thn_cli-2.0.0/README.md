\# THN CLI

Internal development CLI for THN Projects



!\[Tests](https://github.com/Cardinal-Fang-78/thn-cli/actions/workflows/tests.yml/badge.svg)

!\[Coverage](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/Cardinal-Fang-78/thn-cli/main/coverage-badge.json)

\[!\[codecov](https://codecov.io/gh/Cardinal-Fang-78/thn-cli/branch/main/graph/badge.svg)](https://codecov.io/gh/Cardinal-Fang-78/thn-cli)
