# thn_cli/syncv2/delta/__init__.py
"""
Sync V2 CDC-Delta subsystem.

Exposes chunking, manifest, and remote negotiation helpers.
"""
