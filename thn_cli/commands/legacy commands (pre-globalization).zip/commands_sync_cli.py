"""
THN Sync CLI Command
--------------------

Implements:

    thn sync cli --input <folder-or-file> [--dry-run | --apply]

Builds a temporary ZIP from input, wraps it as a Sync V2 test envelope,
inspects, then applies to the CLI sync target.
"""

from __future__ import annotations

import argparse
import os
import tempfile
import zipfile

from thn_cli.syncv2.make_test import make_test_envelope
from thn_cli.syncv2.envelope import load_envelope_from_file, inspect_envelope
from thn_cli.syncv2.engine import apply_envelope_v2
from thn_cli.syncv2.targets.cli import CLISyncTarget


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _zip_input(input_path: str) -> str:
    """
    ZIP a folder or file into a temporary ZIP and return its path.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input path does not exist: {input_path}")

    fd, temp_zip = tempfile.mkstemp(suffix=".zip")
    os.close(fd)

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(input_path):
            for root, _, files in os.walk(input_path):
                for name in files:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, input_path)
                    z.write(full, rel)
        else:
            z.write(input_path, os.path.basename(input_path))

    return temp_zip


# ---------------------------------------------------------------------------
# Main Command Handler
# ---------------------------------------------------------------------------

def run_sync_cli(args: argparse.Namespace) -> int:
    input_path = args.input

    print()
    print("==========================================")
    print("       THN SYNC CLI via SYNC V2")
    print("==========================================\n")
    print(f"Input path: {input_path}\n")

    # Step 1 — ZIP input
    print("Step 1: Zipping input folder/file...")
    raw_zip = _zip_input(input_path)
    print(f"\nCreated raw ZIP:\n  {raw_zip}\n")

    # Step 2 — Create envelope
    print("Step 2: Creating V2 envelope...")
    result = make_test_envelope(raw_zip)
    envelope_zip = result.get("envelope_zip")

    if not envelope_zip:
        raise RuntimeError("make_test_envelope did not return 'envelope_zip'")

    print(f"\nGenerated envelope ZIP:\n  {envelope_zip}\n")

    # Step 3 — Load envelope
    print("Step 3: Loading envelope...")
    env = load_envelope_from_file(envelope_zip)
    print()

    # Step 4 — Inspect
    print("Step 4: Inspecting envelope...\n")
    print(inspect_envelope(env))
    print()

    # Step 5 — Determine dry-run vs apply
    dry_run = bool(args.dry_run)
    explicit_apply = bool(args.apply)

    if not dry_run and not explicit_apply:
        print("No --dry-run or --apply flag given; defaulting to DRY RUN.\n")
        dry_run = True

    print("Step 5: Applying envelope...")
    print(f"  Dry run : {dry_run}\n")

    target = CLISyncTarget()
    result_json = apply_envelope_v2(env, target, dry_run=dry_run)

    print(result_json)
    print("\nTHN Sync CLI workflow complete.\n")
    return 0


# ---------------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------------

def add_subparser(sync_subparsers: argparse._SubParsersAction) -> None:
    """
    Registers:

        thn sync cli --input <folder-or-file> [--dry-run | --apply]
    """
    parser = sync_subparsers.add_parser(
        "cli",
        help="Sync CLI tool assets via the Sync V2 engine.",
        description=(
            "ZIPs input, builds a test envelope, inspects it, and applies it "
            "to the CLI sync target. Defaults to dry-run unless --apply is used."
        ),
    )

    parser.add_argument(
        "--input", "--in", "-i",
        dest="input",
        required=True,
        help="Folder or file to sync (zipped automatically).",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate apply without writing files.",
    )

    parser.add_argument(
        "--apply",
        action="store_true",
        help="Perform a live apply (write files).",
    )

    parser.set_defaults(func=run_sync_cli)
