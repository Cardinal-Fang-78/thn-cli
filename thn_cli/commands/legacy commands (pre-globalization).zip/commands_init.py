"""
THN Init Command
----------------

Initializes the full THN directory structure as defined by get_thn_paths().
This ensures the THN environment can run without missing-folder issues.

Command:

    thn init
"""

from __future__ import annotations

import argparse
import os
import json

from thn_cli.pathing import get_thn_paths


# ---------------------------------------------------------------------------
# Command Handler
# ---------------------------------------------------------------------------

def run_init(args: argparse.Namespace) -> int:
    """
    Create all required THN folders according to the path map.
    """
    paths = get_thn_paths()
    created = []

    # For each mapped path, ensure creation
    for name, path in paths.items():
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
                created.append(path)
        except Exception as e:
            print("\nTHN Init Error\n")
            print(json.dumps({
                "status": "ERROR",
                "path": path,
                "exception": str(e),
            }, indent=4))
            print()
            return 1

    print("\nTHN Init\n")
    print(json.dumps({
        "status": "OK",
        "created": created,
        "paths": paths,
    }, indent=4))
    print()

    return 0


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Register: thn init
    """
    parser = subparsers.add_parser(
        "init",
        help="Initialize THN system folders.",
        description="Creates core, sync, state, routing, and project directories.",
    )

    parser.set_defaults(func=run_init)
