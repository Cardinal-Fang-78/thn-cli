"""
THN Blueprint Command Group
---------------------------

Implements:

    thn blueprint apply    --name NAME --var key=value ...
    thn blueprint list
    thn blueprint validate --name NAME
    thn blueprint validate --all

Supports parsing of template variables, applying blueprints,
listing available blueprints, and validating blueprint structures.
"""

from __future__ import annotations

import json
from typing import Dict, Any, List

from thn_cli.blueprints.engine import apply_blueprint
from thn_cli.blueprints.manager import list_blueprints
from thn_cli.blueprints.validator import (
    validate_blueprint,
    validate_all_blueprints,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_vars(var_args: List[str]) -> Dict[str, Any]:
    """
    Parse repeated:

        --var key=value

    into:

        { "key": "value", ... }

    Malformed entries are ignored instead of raising errors.
    """
    result: Dict[str, Any] = {}

    for item in var_args:
        if "=" not in item:
            continue

        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key:
            result[key] = value

    return result


# ---------------------------------------------------------------------------
# Subcommand Handlers
# ---------------------------------------------------------------------------

def run_blueprint_apply(args) -> int:
    """
    Handler for:

        thn blueprint apply --name NAME --var key=value ...
    """
    if not args.name:
        print("Error: --name is required for 'blueprint apply'.")
        return 1

    var_dict = _parse_vars(args.var or [])

    result = apply_blueprint(args.name, var_dict)

    print("\nTHN Blueprint Apply\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


def run_blueprint_list(args) -> int:
    """
    Handler for:

        thn blueprint list
    """
    names = list_blueprints()

    print("\nTHN Blueprints Available\n")

    if not names:
        print("(none)\n")
        return 0

    for name in names:
        print(f"- {name}")

    print()
    return 0


def run_blueprint_validate(args) -> int:
    """
    Handler for:

        thn blueprint validate --name NAME
        thn blueprint validate --all
    """
    # Validate all blueprints
    if args.all:
        result = validate_all_blueprints()
        print("\nTHN Blueprint Validate (All)\n")
        print(json.dumps(result, indent=4))
        print()
        return 0

    # Validate a single blueprint
    if not args.name:
        print("Error: either --name or --all must be provided for 'blueprint validate'.")
        return 1

    result = validate_blueprint(args.name)

    print("\nTHN Blueprint Validate\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Command Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers) -> None:
    """
    Register:

        thn blueprint ...
    """
    parser = subparsers.add_parser(
        "blueprint",
        help="Blueprint utilities for THN.",
        description="Apply, list, and validate THN blueprints.",
    )

    sub = parser.add_subparsers(dest="blueprint_command")

    # ----------------------------------------------------------------------
    # thn blueprint apply
    # ----------------------------------------------------------------------
    p_apply = sub.add_parser(
        "apply",
        help="Apply a blueprint to generate files.",
        description="Applies a blueprint using provided template variables.",
    )
    p_apply.add_argument(
        "--name",
        required=True,
        help="Name of the blueprint to apply.",
    )
    p_apply.add_argument(
        "--var",
        action="append",
        default=[],
        help="Template variable key=value (repeatable).",
    )
    p_apply.set_defaults(func=run_blueprint_apply)

    # ----------------------------------------------------------------------
    # thn blueprint list
    # ----------------------------------------------------------------------
    p_list = sub.add_parser(
        "list",
        help="List available blueprints.",
        description="Displays all blueprints located under the THN blueprint root.",
    )
    p_list.set_defaults(func=run_blueprint_list)

    # ----------------------------------------------------------------------
    # thn blueprint validate
    # ----------------------------------------------------------------------
    p_validate = sub.add_parser(
        "validate",
        help="Validate blueprint definitions and templates.",
        description="Validate one or all blueprints for correctness.",
    )
    p_validate.add_argument(
        "--name",
        help="Validate a single blueprint.",
    )
    p_validate.add_argument(
        "--all",
        action="store_true",
        help="Validate all blueprints.",
    )
    p_validate.set_defaults(func=run_blueprint_validate)

    # Default action: show help
    parser.set_defaults(func=lambda args: parser.print_help())
