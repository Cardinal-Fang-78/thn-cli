# thn_cli/commands_sync_docs.py

"""
THN Sync Docs Command
---------------------

Implements:

    thn sync docs --input <folder-or-file> [--dry-run | --apply]

The DocsSyncTarget uses the Sync V2 engine. This tool:

    • Zips a folder or file
    • Builds a V2 envelope
    • Inspects the envelope
    • Applies it to the Docs sync target (or performs a dry run)
"""

from __future__ import annotations

import argparse
import os
import tempfile
import zipfile

from thn_cli.syncv2.make_test import make_test_envelope
from thn_cli.syncv2.envelope import (
    load_envelope_from_file,
    inspect_envelope,
)
from thn_cli.syncv2.engine import apply_envelope_v2
from thn_cli.syncv2.targets.docs import DocsSyncTarget


# ---------------------------------------------------------------------------
# ZIP Helper
# ---------------------------------------------------------------------------

def _zip_input(input_path: str) -> str:
    """
    Zip a folder or single file into a temporary ZIP.
    Returns the path to the created ZIP file.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input path does not exist: {input_path}")

    fd, temp_zip = tempfile.mkstemp(suffix=".zip")
    os.close(fd)

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(input_path):
            for root, _, files in os.walk(input_path):
                for name in files:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, input_path)
                    z.write(full, rel)
        else:
            z.write(input_path, os.path.basename(input_path))

    return temp_zip


# ---------------------------------------------------------------------------
# Main Implementation
# ---------------------------------------------------------------------------

def run_sync_docs(args: argparse.Namespace) -> None:
    """
    Entrypoint for:

        thn sync docs --input <path> [--dry-run | --apply]
    """
    input_path = args.input

    print()
    print("==========================================")
    print("        THN SYNC DOCS via SYNC V2")
    print("==========================================")
    print()
    print(f"Input path: {input_path}")
    print()

    # -------------------------------------------------------------
    # Step 1: ZIP input
    # -------------------------------------------------------------
    print("Step 1: Zipping input folder/file...")
    raw_zip = _zip_input(input_path)
    print(f"\nCreated raw ZIP:\n  {raw_zip}\n")

    # -------------------------------------------------------------
    # Step 2: Build envelope
    # -------------------------------------------------------------
    print("Step 2: Creating V2 envelope...")
    result = make_test_envelope(raw_zip)

    envelope_zip = result.get("envelope_zip")
    if not envelope_zip:
        raise RuntimeError("make_test_envelope() did not return 'envelope_zip'")

    print(f"\nGenerated envelope ZIP:\n  {envelope_zip}\n")

    # -------------------------------------------------------------
    # Step 3: Load envelope
    # -------------------------------------------------------------
    print("Step 3: Loading envelope...")
    env = load_envelope_from_file(envelope_zip)
    print()

    # -------------------------------------------------------------
    # Step 4: Inspect envelope
    # -------------------------------------------------------------
    print("Step 4: Inspecting envelope...\n")
    info_json = inspect_envelope(env)
    print(info_json)
    print()

    # -------------------------------------------------------------
    # Step 5: Apply or dry-run
    # -------------------------------------------------------------
    dry_run = bool(args.dry_run)
    explicit_apply = bool(args.apply)

    if not dry_run and not explicit_apply:
        print("No --dry-run or --apply flag given; defaulting to DRY RUN.\n")
        dry_run = True

    print("Step 5: Applying envelope...")
    print(f"  Dry run : {dry_run}\n")

    target = DocsSyncTarget()
    result_json = apply_envelope_v2(env, target, dry_run=dry_run)

    print(result_json)
    print("\nTHN Sync Docs workflow complete.\n")


# ---------------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------------

def add_subparser(sync_subparsers: argparse._SubParsersAction) -> None:
    """
    Register:

        thn sync docs --input <folder-or-file> [--dry-run | --apply]
    """
    parser = sync_subparsers.add_parser(
        "docs",
        help="Sync documentation assets via the Sync V2 engine.",
        description=(
            "Zips a folder or file, builds a V2 envelope, inspects it, "
            "and applies it to the THN Docs target. "
            "Defaults to dry-run unless --apply is specified."
        ),
    )

    parser.add_argument(
        "--input", "--in", "-i",
        dest="input",
        required=True,
        help="Folder or file to sync (zipped automatically).",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Inspect envelope and simulate apply without writing.",
    )

    parser.add_argument(
        "--apply",
        action="store_true",
        help="Perform a live apply (write files).",
    )

    parser.set_defaults(func=run_sync_docs)
