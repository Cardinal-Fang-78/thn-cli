"""
THN Plugin Management Commands
------------------------------

Provides:

    thn plugins list
    thn plugins info <name>
    thn plugins enable <name>
    thn plugins disable <name>

This subsystem manages the plugin registry, allowing discovery,
status inspection, and enable/disable toggling for installed plugins.
"""

from __future__ import annotations

import argparse
import json

from thn_cli.plugins.plugin_loader import (
    list_plugins,
    get_plugin_info,
    set_plugin_enabled,
    ensure_registry_seeded,
)


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

def run_plugins_list(args: argparse.Namespace) -> int:
    ensure_registry_seeded()
    plugins = list_plugins()

    if not plugins:
        print("\nNo plugins registered.\n")
        return 0

    print("\nTHN Plugins\n")
    for p in plugins:
        status = "enabled" if p["enabled"] else "disabled"
        print(f"- {p['name']} [{status}]")
        print(f"    Module     : {p['module']}")
        if p.get("description"):
            print(f"    Description: {p['description']}")
        print()

    return 0


def run_plugins_info(args: argparse.Namespace) -> int:
    ensure_registry_seeded()
    info = get_plugin_info(args.name)

    if not info:
        print(f"\nPlugin '{args.name}' not found in registry.\n")
        return 1

    print("\nPlugin Info\n")
    print(json.dumps(info, indent=4))
    print()
    return 0


def run_plugins_enable(args: argparse.Namespace) -> int:
    ensure_registry_seeded()
    if not set_plugin_enabled(args.name, True):
        print(f"\nPlugin '{args.name}' not found in registry.\n")
        return 1

    print(f"\nPlugin '{args.name}' enabled.\n")
    return 0


def run_plugins_disable(args: argparse.Namespace) -> int:
    ensure_registry_seeded()
    if not set_plugin_enabled(args.name, False):
        print(f"\nPlugin '{args.name}' not found in registry.\n")
        return 1

    print(f"\nPlugin '{args.name}' disabled.\n")
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "plugins",
        help="Manage THN CLI plugins.",
        description="List, inspect, enable, or disable THN CLI plugins.",
    )

    sub = parser.add_subparsers(dest="plugins_command", required=True)

    # list
    p_list = sub.add_parser("list", help="List registered plugins.")
    p_list.set_defaults(func=run_plugins_list)

    # info
    p_info = sub.add_parser("info", help="Show plugin details.")
    p_info.add_argument("name", help="Plugin name.")
    p_info.set_defaults(func=run_plugins_info)

    # enable
    p_enable = sub.add_parser("enable", help="Enable a plugin.")
    p_enable.add_argument("name", help="Plugin name.")
    p_enable.set_defaults(func=run_plugins_enable)

    # disable
    p_disable = sub.add_parser("disable", help="Disable a plugin.")
    p_disable.add_argument("name", help="Plugin name.")
    p_disable.set_defaults(func=run_plugins_disable)

    parser.set_defaults(func=lambda args: parser.print_help())
