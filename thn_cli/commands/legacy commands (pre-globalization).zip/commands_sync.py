"""
THN Sync V2 Command Group
-------------------------

Provides operations for inspecting, applying, and generating Sync V2 envelopes.

Commands:

    thn sync inspect <zip>
    thn sync apply <zip> [--dry-run]
    thn sync make-test --in <folder>

And registers the legacy:
    thn sync web
"""

from __future__ import annotations

import argparse
import json
import os

from thn_cli.syncv2.envelope import (
    load_envelope_from_file,
    inspect_envelope,
    apply_envelope,
)
from thn_cli.syncv2.make_test import make_test_envelope

# Legacy Sync Web command
from .commands_sync_web import add_subparser as add_web_subparser


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

def run_sync_inspect(args: argparse.Namespace) -> int:
    env = load_envelope_from_file(args.zip)
    print(inspect_envelope(env))
    return 0


def run_sync_apply(args: argparse.Namespace) -> int:
    env = load_envelope_from_file(args.zip)
    result = apply_envelope(env, dry_run=args.dry_run)
    print(result)
    return 0


def run_sync_make_test(args: argparse.Namespace) -> int:
    result = make_test_envelope(args.in_path)
    print(json.dumps(result, indent=4))
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "sync",
        help="Sync V2 envelope utilities.",
        description="Inspect, apply, or generate THN Sync V2 envelopes.",
    )

    sync_sub = parser.add_subparsers(dest="sync_command")

    # ----------------------------------------------------------------------
    # thn sync inspect <zip>
    # ----------------------------------------------------------------------
    p_inspect = sync_sub.add_parser(
        "inspect",
        help="Inspect a Sync V2 envelope.",
    )
    p_inspect.add_argument(
        "zip",
        help="Path to the envelope ZIP.",
    )
    p_inspect.set_defaults(func=run_sync_inspect)

    # ----------------------------------------------------------------------
    # thn sync apply <zip> [--dry-run]
    # ----------------------------------------------------------------------
    p_apply = sync_sub.add_parser(
        "apply",
        help="Apply a Sync V2 envelope.",
    )
    p_apply.add_argument(
        "zip",
        help="Path to the envelope ZIP.",
    )
    p_apply.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate apply without modifying target.",
    )
    p_apply.set_defaults(func=run_sync_apply)

    # ----------------------------------------------------------------------
    # thn sync make-test --in <folder>
    # ----------------------------------------------------------------------
    p_test = sync_sub.add_parser(
        "make-test",
        help="Generate + inspect + apply a test envelope from an input folder.",
    )
    p_test.add_argument(
        "--in",
        dest="in_path",
        required=True,
        help="Folder to package into a test envelope.",
    )
    p_test.set_defaults(func=run_sync_make_test)

    # ----------------------------------------------------------------------
    # Legacy Sync Web integration
    # ----------------------------------------------------------------------
    add_web_subparser(sync_sub)

    # Fallback help
    parser.set_defaults(func=lambda args: parser.print_help())
