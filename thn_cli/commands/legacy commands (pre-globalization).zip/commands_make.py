"""
THN Make Command Group
----------------------

Provides:

    thn make project <name> --var key=value ...
    thn make module <project> <name> --var key=value ...

Creates new THN projects or modules using blueprint-driven scaffolding and
updates the THN registry accordingly.
"""

from __future__ import annotations

import os
import json
import argparse
from typing import Dict, List

from thn_cli.pathing import get_thn_paths
from thn_cli.blueprints.engine import apply_blueprint
from thn_cli.registry import load_registry, save_registry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_vars(var_list: List[str]) -> Dict[str, str]:
    """
    Parse repeated --var key=value arguments into a dictionary.
    """
    result: Dict[str, str] = {}
    if not var_list:
        return result

    for item in var_list:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        result[key.strip()] = value.strip()

    return result


# ---------------------------------------------------------------------------
# Project Creation
# ---------------------------------------------------------------------------

def run_make_project(args: argparse.Namespace) -> int:
    """
    thn make project <name> --var owner=... --var created=...

    Generates a new project using the 'project_default' blueprint and records
    it in the THN registry.
    """
    paths = get_thn_paths()
    registry = load_registry(paths)

    project_name = args.name
    var_dict = _parse_vars(args.var)

    # Required variables for this blueprint
    var_dict.setdefault("project_name", project_name)
    var_dict.setdefault("owner", "Unknown")
    var_dict.setdefault("created", "")

    output_root = paths["projects"]

    # Apply blueprint
    bp_result = apply_blueprint(
        "project_default",
        var_dict,
        output_root=output_root,
    )

    project_path = os.path.join(output_root, project_name)

    projects = registry.get("projects", {})
    existing = projects.get(project_name, {})

    project_record = {
        "owner": var_dict.get("owner", existing.get("owner", "Unknown")),
        "created": var_dict.get("created", existing.get("created", "")),
        "path": existing.get("path", project_path),
        "modules": existing.get("modules", []),
        "meta": existing.get("meta", {}),
    }

    # Update registry
    projects[project_name] = project_record
    registry["projects"] = projects
    save_registry(paths, registry)

    summary = {
        "blueprint_result": bp_result,
        "registry_project": project_record,
    }

    print("\nTHN Make Project\n")
    print(json.dumps(summary, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Module Creation
# ---------------------------------------------------------------------------

def run_make_module(args: argparse.Namespace) -> int:
    """
    thn make module <project> <name> --var created=...

    Generates a module under the specified project using the
    'module_default' blueprint and updates the project's module list.
    """
    paths = get_thn_paths()
    registry = load_registry(paths)

    project_name = args.project
    module_name = args.name
    var_dict = _parse_vars(args.var)

    projects = registry.get("projects", {})
    if project_name not in projects:
        print("\nError: Project not found in registry.\n")
        print(f"  Project: {project_name}")
        print()
        return 1

    project_record = projects[project_name]
    project_path = project_record.get(
        "path",
        os.path.join(paths["projects"], project_name),
    )

    module_path = os.path.join(project_path, "modules", module_name)

    # Required variables for blueprint
    var_dict.setdefault("project_name", project_name)
    var_dict.setdefault("module_name", module_name)
    var_dict.setdefault("created", "")

    # Apply blueprint
    bp_result = apply_blueprint(
        "module_default",
        var_dict,
        output_root=paths["projects"],
    )

    # Normalize modules to a list
    modules = project_record.get("modules", [])
    if isinstance(modules, dict):
        modules = list(modules.values())

    # Remove any existing module with this name
    modules = [m for m in modules if m.get("name") != module_name]

    module_record = {
        "name": module_name,
        "created": var_dict.get("created", ""),
        "path": module_path,
        "tasks": [],
        "config": {},
        "meta": {
            "type": "module",
            "version": 1,
        },
    }

    modules.append(module_record)

    # Save back
    project_record["modules"] = modules
    projects[project_name] = project_record
    registry["projects"] = projects
    save_registry(paths, registry)

    summary = {
        "blueprint_result": bp_result,
        "registry_project": project_record,
        "registry_module": module_record,
    }

    print("\nTHN Make Module\n")
    print(json.dumps(summary, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Parser Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Register the 'make' command group:

        thn make project <name>
        thn make module <project> <name>
    """
    parser = subparsers.add_parser(
        "make",
        help="Create THN projects or modules.",
        description="Blueprint-driven creation utilities for THN.",
    )

    sub = parser.add_subparsers(dest="make_command")

    # Project
    proj = sub.add_parser(
        "project",
        help="Create a new project using the 'project_default' blueprint.",
    )
    proj.add_argument("name", help="Project name.")
    proj.add_argument(
        "--var",
        action="append",
        default=[],
        help="Template variable in key=value form (repeatable).",
    )
    proj.set_defaults(func=run_make_project)

    # Module
    mod = sub.add_parser(
        "module",
        help="Create a module under an existing project using the 'module_default' blueprint.",
    )
    mod.add_argument("project", help="Project name.")
    mod.add_argument("name", help="Module name.")
    mod.add_argument(
        "--var",
        action="append",
        default=[],
        help="Template variable in key=value form (repeatable).",
    )
    mod.set_defaults(func=run_make_module)

    # Default: show help
    parser.set_defaults(func=lambda args: parser.print_help())
