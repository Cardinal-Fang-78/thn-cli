"""
THN Diagnostic Command Group
----------------------------

Provides the following commands:

    thn diag env
    thn diag routing
    thn diag registry
    thn diag plugins
    thn diag tasks
    thn diag ui
    thn diag hub
    thn diag sanity

Each diagnostic returns structured JSON summarizing subsystem status.
"""

from __future__ import annotations

import json
import argparse

from thn_cli.diagnostics.env_diag import diagnose_env
from thn_cli.diagnostics.routing_diag import diagnose_routing
from thn_cli.diagnostics.registry_diag import diagnose_registry
from thn_cli.diagnostics.plugins_diag import diagnose_plugins
from thn_cli.diagnostics.tasks_diag import diagnose_tasks
from thn_cli.diagnostics.ui_diag import diagnose_ui
from thn_cli.diagnostics.hub_diag import diagnose_hub
from thn_cli.diagnostics.sanity_diag import run_sanity


# ---------------------------------------------------------------------------
# Diagnostic Handlers
# ---------------------------------------------------------------------------

def run_diag_env(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_env(), indent=4))
    return 0


def run_diag_routing(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_routing(), indent=4))
    return 0


def run_diag_registry(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_registry(), indent=4))
    return 0


def run_diag_plugins(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_plugins(), indent=4))
    return 0


def run_diag_tasks(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_tasks(), indent=4))
    return 0


def run_diag_ui(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_ui(), indent=4))
    return 0


def run_diag_hub(args: argparse.Namespace) -> int:
    print(json.dumps(diagnose_hub(), indent=4))
    return 0


def run_diag_sanity(args: argparse.Namespace) -> int:
    print(json.dumps(run_sanity(), indent=4))
    return 0


# ---------------------------------------------------------------------------
# Command Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Register:

        thn diag ...
    """
    parser = subparsers.add_parser(
        "diag",
        help="Diagnostic utilities.",
        description="Diagnostic reports for all major THN subsystems.",
    )

    sub = parser.add_subparsers(dest="diag_cmd")

    # ----------------------------------------------------------------------
    # Individual diagnostic commands
    # ----------------------------------------------------------------------

    p_env = sub.add_parser(
        "env",
        help="Check the THN environment.",
        description="Validate OS environment, paths, variables, and local prerequisites.",
    )
    p_env.set_defaults(func=run_diag_env)

    p_route = sub.add_parser(
        "routing",
        help="Check routing system.",
        description="Validate routing rules, classifier configs, and schema correctness.",
    )
    p_route.set_defaults(func=run_diag_routing)

    p_reg = sub.add_parser(
        "registry",
        help="Check registry status.",
        description="Inspect THN registry.json structure, versioning, and integrity.",
    )
    p_reg.set_defaults(func=run_diag_registry)

    p_plugins = sub.add_parser(
        "plugins",
        help="Check plugin system.",
        description="Scan plugin loader, registry, and plugin integrity.",
    )
    p_plugins.set_defaults(func=run_diag_plugins)

    p_tasks = sub.add_parser(
        "tasks",
        help="Check background task subsystem.",
        description="Inspect task registry, scheduler readiness, and consistency.",
    )
    p_tasks.set_defaults(func=run_diag_tasks)

    p_ui = sub.add_parser(
        "ui",
        help="Check UI subsystem.",
        description="Validate UI launcher, API surface, and UI-related paths.",
    )
    p_ui.set_defaults(func=run_diag_ui)

    p_hub = sub.add_parser(
        "hub",
        help="Check THN Hub connectivity.",
        description="Diagnose communication readiness with the THN Hub.",
    )
    p_hub.set_defaults(func=run_diag_hub)

    p_sanity = sub.add_parser(
        "sanity",
        help="Run full system validation.",
        description="Perform a comprehensive multi-subsystem THN sanity check.",
    )
    p_sanity.set_defaults(func=run_diag_sanity)

    # Default: show help if no subcommand chosen
    parser.set_defaults(func=lambda args: parser.print_help())
