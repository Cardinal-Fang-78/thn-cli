# thn_cli/commands_sync_remote.py

"""
THN Sync Remote Command Group
-----------------------------

Implements:

    thn sync-remote web  --input <path> --url <remote_url> [--dry-run | --apply]
    thn sync-remote cli  --input <path> --url <remote_url> [--dry-run | --apply]
    thn sync-remote docs --input <path> --url <remote_url> [--dry-run | --apply]

Workflow:

    • ZIP input
    • Build Sync V2 envelope
    • Inspect envelope locally
    • Send envelope to remote Sync server
    • Remote validates + (optionally) applies changes
"""

from __future__ import annotations

import argparse
import os
import tempfile
import zipfile

from thn_cli.syncv2.make_test import make_test_envelope
from thn_cli.syncv2.envelope import (
    inspect_envelope,
    load_envelope_from_file,
)
from thn_cli.syncv2.remote_client import send_envelope_to_remote


# ---------------------------------------------------------------------------
# ZIP Helper
# ---------------------------------------------------------------------------

def _zip_input(input_path: str) -> str:
    """
    ZIP a folder or single file into a temporary ZIP.
    Returns the path to the created ZIP file.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input path does not exist: {input_path}")

    fd, temp_zip = tempfile.mkstemp(suffix=".zip")
    os.close(fd)

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(input_path):
            for root, _, files in os.walk(input_path):
                for name in files:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, input_path)
                    z.write(full, rel)
        else:
            z.write(input_path, os.path.basename(input_path))

    return temp_zip


# ---------------------------------------------------------------------------
# Core Shared Logic
# ---------------------------------------------------------------------------

def _run_sync_remote_common(args: argparse.Namespace, target_name: str) -> None:
    """
    Shared implementation for all remote targets:
        web, cli, docs
    """
    input_path = args.input
    remote_url = args.url

    print()
    print("==========================================")
    print(f"   THN SYNC REMOTE ({target_name}) via SYNC V2")
    print("==========================================")
    print()
    print(f"Input path : {input_path}")
    print(f"Remote URL : {remote_url}")
    print()

    # -------------------------------------------------------------
    # Step 1: ZIP input
    # -------------------------------------------------------------
    print("Step 1: Zipping input folder/file...")
    raw_zip = _zip_input(input_path)
    print(f"\nCreated raw ZIP:\n  {raw_zip}\n")

    # -------------------------------------------------------------
    # Step 2: Build envelope
    # -------------------------------------------------------------
    print("Step 2: Creating V2 envelope...")
    env_result = make_test_envelope(raw_zip)

    envelope_zip = env_result.get("envelope_zip")
    if not envelope_zip:
        raise RuntimeError("make_test_envelope() did not return 'envelope_zip'")

    print(f"\nGenerated envelope ZIP:\n  {envelope_zip}\n")

    # -------------------------------------------------------------
    # Step 3: Local inspection
    # -------------------------------------------------------------
    print("Step 3: Inspecting envelope locally...\n")
    env = load_envelope_from_file(envelope_zip)
    info_json = inspect_envelope(env)
    print(info_json)
    print()

    # -------------------------------------------------------------
    # Step 4: Send envelope to remote
    # -------------------------------------------------------------
    dry_run = bool(args.dry_run)
    explicit_apply = bool(args.apply)

    if not dry_run and not explicit_apply:
        print("No --dry-run or --apply flag given; defaulting to DRY RUN.\n")
        dry_run = True

    print("Step 4: Sending envelope to remote...")
    print(f"  Target : {target_name}")
    print(f"  Dry run: {dry_run}")
    print()

    remote_result = send_envelope_to_remote(
        envelope_zip=envelope_zip,
        target_name=target_name,
        url=remote_url,
        dry_run=dry_run,
    )

    print("Remote response:")
    print(remote_result)
    print("\nTHN Sync Remote workflow complete.\n")


# ---------------------------------------------------------------------------
# Target-specific entrypoints
# ---------------------------------------------------------------------------

def run_sync_remote_web(args: argparse.Namespace) -> None:
    _run_sync_remote_common(args, target_name="web")


def run_sync_remote_cli(args: argparse.Namespace) -> None:
    _run_sync_remote_common(args, target_name="cli")


def run_sync_remote_docs(args: argparse.Namespace) -> None:
    _run_sync_remote_common(args, target_name="docs")


# ---------------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------------

def add_subparser(root_subparsers: argparse._SubParsersAction) -> None:
    """
    Register the sync-remote command group:

        thn sync-remote <target> --input <path> --url <remote_url>
    """
    parser = root_subparsers.add_parser(
        "sync-remote",
        help="Push Sync V2 envelopes to a remote host for validation/apply.",
        description=(
            "Zips a folder or file, builds a V2 envelope, inspects it locally, "
            "and sends it to a remote Sync server for apply."
        ),
    )

    remote_subparsers = parser.add_subparsers(
        title="sync-remote targets",
        dest="sync_remote_target",
    )

    def _attach_target_subparser(name: str, func) -> None:
        p = remote_subparsers.add_parser(
            name,
            help=f"Remote sync for {name} target.",
        )

        p.add_argument(
            "--input", "--in", "-i",
            dest="input",
            required=True,
            help="Folder or file to sync (zipped automatically).",
        )
        p.add_argument(
            "--url", "-u",
            dest="url",
            required=True,
            help="Remote Sync server URL (e.g., http://host:8765/sync/apply).",
        )
        p.add_argument(
            "--dry-run",
            action="store_true",
            help="Validate on remote without writing changes.",
        )
        p.add_argument(
            "--apply",
            action="store_true",
            help="Perform a live apply on the remote host.",
        )

        p.set_defaults(func=func)

    _attach_target_subparser("web", run_sync_remote_web)
    _attach_target_subparser("cli", run_sync_remote_cli)
    _attach_target_subparser("docs", run_sync_remote_docs)
