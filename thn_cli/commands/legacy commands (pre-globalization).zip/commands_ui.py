"""
THN UI Command Group
--------------------

Provides user-facing commands for interacting with the THN UI subsystem:

    thn ui status
    thn ui launch
"""

from __future__ import annotations

import argparse
import json

from thn_cli.ui.ui_api import get_ui_status
from thn_cli.ui.ui_launcher import launch_ui


# ---------------------------------------------------------------------------
# Command Implementations
# ---------------------------------------------------------------------------

def run_ui_status(args: argparse.Namespace) -> int:
    """Display the UI subsystem status."""
    status = get_ui_status()

    print("\nTHN UI Status\n")
    print(json.dumps(status, indent=4))
    print()
    return 0


def run_ui_launch(args: argparse.Namespace) -> int:
    """Attempt to launch the UI application."""
    result = launch_ui()

    print("\nTHN UI Launch Attempt\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Register: thn ui ..."""
    parser = subparsers.add_parser(
        "ui",
        help="THN UI subsystem commands.",
        description="Inspect and launch THN UI features.",
    )

    sub = parser.add_subparsers(
        dest="ui_command",
        required=True,
    )

    # ui status
    p_status = sub.add_parser(
        "status",
        help="Show UI subsystem status.",
    )
    p_status.set_defaults(func=run_ui_status)

    # ui launch
    p_launch = sub.add_parser(
        "launch",
        help="Launch the THN UI application.",
    )
    p_launch.set_defaults(func=run_ui_launch)

    # If no subcommand was provided
    parser.set_defaults(func=lambda args: parser.print_help())
