# thn_cli/commands/commands_sync_delta.py

"""
THN Sync-Delta Command
----------------------

CDC-based delta sync engine with Advanced Inspection Pack v2.

Inspection modes (early exit; no manifest building or apply unless requested):

    --inspect-files
    --inspect-tree
    --inspect-chunks
    --inspect-hash
    --inspect-size-summary
    --delta-summary

Filtering:
    --ignore-ext .pyc .zip .log ...
    --ignore-dir __pycache__ temp build ...

Advanced visuals:
    • ASCII chunk map per file

Normal mode:
    Build a CDC-delta manifest and apply it via Sync V2.
"""

from __future__ import annotations

import argparse
import os
import hashlib
from collections import defaultdict

from thn_cli.syncv2.engine import apply_envelope_v2
from thn_cli.syncv2.delta.make_delta import (
    build_cdc_delta_manifest,
    _iter_files,
    _rel_path,
    inspect_file_chunks,
)
from thn_cli.syncv2.delta.store import store_chunk, get_chunk_path
from thn_cli.syncv2.targets.web import WebSyncTarget
from thn_cli.syncv2.targets.cli import CLISyncTarget
from thn_cli.syncv2.targets.docs import DocsSyncTarget


# ---------------------------------------------------------------------------
# Target Resolver
# ---------------------------------------------------------------------------

def _resolve_target(name: str):
    """
    Map short target strings to SyncTarget implementations.
    """
    n = name.lower()
    if n == "web":
        return WebSyncTarget()
    if n == "cli":
        return CLISyncTarget()
    if n == "docs":
        return DocsSyncTarget()
    raise ValueError(f"Unknown sync-delta target: {name!r}")


# ---------------------------------------------------------------------------
# Ignore Filtering
# ---------------------------------------------------------------------------

def _should_ignore(path: str, *, ignore_ext, ignore_dir) -> bool:
    """
    True if path should be excluded based on extension or directory filters.
    """
    p = path.lower()

    if ignore_ext:
        for ext in ignore_ext:
            if p.endswith(ext.lower()):
                return True

    if ignore_dir:
        for d in ignore_dir:
            marker = f"{os.sep}{d.lower()}{os.sep}"
            if marker in p:
                return True

    return False


def _filtered_files(source_root: str, ignore_ext, ignore_dir):
    """
    Iteration wrapper around _iter_files() with ignore rules applied.
    """
    result = []
    for full in _iter_files(source_root):
        if not _should_ignore(full, ignore_ext=ignore_ext, ignore_dir=ignore_dir):
            result.append(full)
    return result


# ---------------------------------------------------------------------------
# Inspection Handlers
# ---------------------------------------------------------------------------

def _inspect_tree(input_path: str, ignore_ext, ignore_dir):
    """
    Print a directory tree respecting ignore rules.
    """
    print("Directory tree:\n")

    for root, dirs, files in os.walk(input_path):

        # prune ignored dirs (prevents os.walk from descending)
        if ignore_dir:
            dirs[:] = [
                d for d in dirs
                if not _should_ignore(
                    os.path.join(root, d),
                    ignore_ext=[],
                    ignore_dir=ignore_dir,
                )
            ]

        level = root.replace(input_path, "").count(os.sep)
        indent = " " * (level * 2)
        print(f"{indent}{os.path.basename(root)}/")

        subindent = " " * ((level + 1) * 2)
        for f in files:
            full = os.path.join(root, f)
            if not _should_ignore(full, ignore_ext, ignore_dir):
                print(f"{subindent}{f}")


def _inspect_files_list(input_path: str, ignore_ext, ignore_dir):
    print("Inspecting files under:", input_path)
    files = _filtered_files(input_path, ignore_ext, ignore_dir)
    for full in files:
        print(" -", _rel_path(input_path, full))
    print(f"\nTotal files detected: {len(files)}")


def _inspect_hashes(input_path: str, ignore_ext, ignore_dir):
    print("SHA-256 file hashes:\n")
    files = _filtered_files(input_path, ignore_ext, ignore_dir)

    for full in files:
        rel = _rel_path(input_path, full)
        h = hashlib.sha256()
        with open(full, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        print(f"{rel}: {h.hexdigest()}")

    print(f"\nTotal hashed files: {len(files)}")


def _inspect_size_summary(input_path: str, ignore_ext, ignore_dir):
    print("Folder size summary:\n")
    totals = defaultdict(int)

    files = _filtered_files(input_path, ignore_ext, ignore_dir)
    for full in files:
        rel = _rel_path(input_path, full)
        parts = rel.split("/")
        folder = "/".join(parts[:-1]) if len(parts) > 1 else "(root)"
        totals[folder] += os.path.getsize(full)

    for folder, size in sorted(totals.items()):
        print(f"{folder:40}  {size:12} bytes")

    print("\nFolder count:", len(totals))


def _ascii_chunk_map(sizes):
    """
    Build ASCII bar graph representing relative chunk sizes.
    """
    if not sizes:
        return "(no chunks)"

    total = sum(sizes)
    if total <= 0:
        return "(no chunks)"

    SCALE = 40
    bar = ""

    for sz in sizes:
        width = max(1, int((sz / total) * SCALE))
        bar += "▓" * width

    return bar


def _inspect_chunks_verbose(input_path: str, ignore_ext, ignore_dir, target_name: str):
    print("Inspecting CDC chunks for all files...\n")
    files = _filtered_files(input_path, ignore_ext, ignore_dir)

    for full in files:
        rel = _rel_path(input_path, full)
        sizes, chunk_ids = inspect_file_chunks(full, target_name=target_name)

        print(f"File: {rel}")
        print(f"  chunks: {len(chunk_ids)}")
        print(f"  ASCII map: {_ascii_chunk_map(sizes)}")

        for i, (sz, cid) in enumerate(zip(sizes, chunk_ids)):
            print(f"    [{i}] size={sz:7} bytes   id={cid}")
        print()

    print("Total files scanned:", len(files))


def _delta_summary(input_path: str, ignore_ext, ignore_dir, target_name: str):
    print("Delta Summary (dedup + chunk stats):\n")

    files = _filtered_files(input_path, ignore_ext, ignore_dir)

    total_chunks = 0
    unique_chunks = set()
    chunk_size_total = 0

    for full in files:
        sizes, chunk_ids = inspect_file_chunks(full, target_name=target_name)
        total_chunks += len(chunk_ids)
        unique_chunks.update(chunk_ids)
        chunk_size_total += sum(sizes)

    dedup_hits = total_chunks - len(unique_chunks)

    print(f"Files scanned      : {len(files)}")
    print(f"Total chunks       : {total_chunks}")
    print(f"Unique chunks      : {len(unique_chunks)}")
    print(f"Dedup hits         : {dedup_hits}")
    print(f"Total data (bytes) : {chunk_size_total}")

    print("\nEstimated storage impact:")
    print(f"  If fully stored:              {chunk_size_total} bytes")
    print("  If dedup applied (unique only): (reduced write cost)\n")


# ---------------------------------------------------------------------------
# Main Command Entry
# ---------------------------------------------------------------------------

def run_sync_delta(args: argparse.Namespace) -> None:
    """
    Entrypoint for:   thn sync-delta <target> --input ...
    Handles inspections or full CDC-delta apply.
    """
    target_name = args.target
    input_path = os.path.abspath(args.input)

    ignore_ext = args.ignore_ext or []
    ignore_dir = args.ignore_dir or []

    # Inspection modes — early exit
    if args.inspect_tree:
        _inspect_tree(input_path, ignore_ext, ignore_dir)
        return

    if args.inspect_files:
        _inspect_files_list(input_path, ignore_ext, ignore_dir)
        return

    if args.inspect_hash:
        _inspect_hashes(input_path, ignore_ext, ignore_dir)
        return

    if args.inspect_size_summary:
        _inspect_size_summary(input_path, ignore_ext, ignore_dir)
        return

    if args.inspect_chunks:
        _inspect_chunks_verbose(input_path, ignore_ext, ignore_dir, target_name)
        return

    if args.delta_summary:
        _delta_summary(input_path, ignore_ext, ignore_dir, target_name)
        return

    # ------------------------------------------------------------------
    # Standard CDC-delta execution
    # ------------------------------------------------------------------

    print()
    print("==========================================")
    print("        THN SYNC DELTA (CDC mode)")
    print("==========================================\n")
    print(f"Target     : {target_name}")
    print(f"Input path : {input_path}\n")

    target = _resolve_target(target_name)

    print("Step 1: Building CDC-delta manifest...")
    manifest = build_cdc_delta_manifest(
        source_root=input_path,
        target_name=target.name,
    )
    print(
        f"  Files     : {manifest.get('file_count')}\n"
        f"  Total size: {manifest.get('total_size')} bytes\n"
    )

    envelope = {
        "manifest": manifest,
        "payload_zip": None,
    }

    dry_run = bool(args.dry_run)
    if not dry_run and not args.apply:
        print("No --dry-run or --apply flag given; defaulting to DRY RUN.\n")
        dry_run = True

    print("Step 3: Applying CDC-delta envelope...")
    print(f"  Dry run : {dry_run}\n")

    result = apply_envelope_v2(envelope=envelope, target=target, dry_run=dry_run)

    print("Result:")
    print(result)
    print("\nTHN Sync Delta workflow complete.\n")


# ---------------------------------------------------------------------------
# Parser Setup
# ---------------------------------------------------------------------------

def add_subparser(root_subparsers: argparse._SubParsersAction) -> None:
    """
    Register: thn sync-delta <target> --input <folder> [options]
    """
    parser = root_subparsers.add_parser(
        "sync-delta",
        help="Run CDC-based delta sync with advanced inspection tools.",
        description=(
            "Build a CDC-delta manifest and optionally apply it. "
            "Provides extensive inspection utilities for debugging file sets, "
            "chunking, hashing, deduplication, and directory structure."
        ),
    )

    parser.add_argument(
        "target",
        choices=["web", "cli", "docs"],
        help="Delta sync target.",
    )

    parser.add_argument(
        "--input", "--in", "-i",
        dest="input",
        required=True,
        help="Source folder to delta-sync from.",
    )

    # Apply controls
    parser.add_argument("--dry-run", action="store_true", help="Simulate apply.")
    parser.add_argument("--apply", action="store_true", help="Write changes.")

    # Inspection modes
    parser.add_argument("--inspect-files",        action="store_true", help="List filtered files.")
    parser.add_argument("--inspect-chunks",       action="store_true", help="Show chunk boundaries + IDs.")
    parser.add_argument("--inspect-tree",         action="store_true", help="Directory tree output.")
    parser.add_argument("--inspect-hash",         action="store_true", help="SHA-256 hashes per file.")
    parser.add_argument("--inspect-size-summary", action="store_true", help="Folder size summary.")
    parser.add_argument("--delta-summary",        action="store_true", help="Dedup + chunk statistics.")

    # Filters
    parser.add_argument("--ignore-ext", nargs="*", help="Ignore extensions (e.g., .pyc .zip).")
    parser.add_argument("--ignore-dir", nargs="*", help="Ignore directory names.")

    parser.set_defaults(func=run_sync_delta)
