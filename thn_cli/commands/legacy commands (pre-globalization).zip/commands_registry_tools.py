"""
THN Registry CLI Commands
-------------------------

Provides utilities for reading, validating, resetting, and inspecting
the THN system registry stored under the state subsystem.

Commands:

    thn registry show
    thn registry reset
    thn registry validate
    thn registry recent [--limit N]
"""

from __future__ import annotations

import argparse
import json

from thn_cli.pathing import get_thn_paths
from thn_cli.registry import (
    load_registry,
    save_registry,
    validate_registry,
    get_recent_events,
)


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

def run_registry_show(args: argparse.Namespace) -> None:
    paths = get_thn_paths()
    reg = load_registry(paths)

    print("\nTHN Registry\n")
    print(json.dumps(reg, indent=4))


def run_registry_reset(args: argparse.Namespace) -> None:
    paths = get_thn_paths()

    reg = {
        "version": 1,
        "projects": {},
        "events": [],
    }
    save_registry(paths, reg)

    print("\nRegistry reset complete.\n")


def run_registry_validate(args: argparse.Namespace) -> None:
    paths = get_thn_paths()
    reg = load_registry(paths)
    result = validate_registry(reg)

    print("\nTHN Registry Validation\n")
    print(json.dumps(result, indent=4))
    print()


def run_registry_recent(args: argparse.Namespace) -> None:
    paths = get_thn_paths()
    reg = load_registry(paths)

    events = get_recent_events(reg, limit=args.limit)

    print("\nTHN Registry - Recent Events\n")
    if not events:
        print("(no registry events logged yet)\n")
        return

    print(json.dumps(events, indent=4))
    print()


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "registry",
        help="Inspect and manipulate the THN registry.",
        description="Registry utilities for THN system state tracking.",
    )

    reg_sub = parser.add_subparsers(dest="registry_cmd", required=True)

    # show
    p_show = reg_sub.add_parser("show", help="Show registry contents.")
    p_show.set_defaults(func=run_registry_show)

    # reset
    p_reset = reg_sub.add_parser("reset", help="Reset registry to empty state.")
    p_reset.set_defaults(func=run_registry_reset)

    # validate
    p_validate = reg_sub.add_parser("validate", help="Validate registry structure.")
    p_validate.set_defaults(func=run_registry_validate)

    # recent
    p_recent = reg_sub.add_parser("recent", help="Show recent registry events.")
    p_recent.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Maximum number of events to display.",
    )
    p_recent.set_defaults(func=run_registry_recent)

    # default
    parser.set_defaults(func=lambda args: parser.print_help())
