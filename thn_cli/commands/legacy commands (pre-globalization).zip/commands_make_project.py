"""
Legacy Shim: commands_make_project
----------------------------------

This module exists only for backward compatibility with older THN CLI
versions that referenced 'commands_make_project'.

All project-creation functionality is now implemented in:

    thn_cli.commands.commands_make

This file intentionally registers **no commands** and defines **no
add_subparser()** function to avoid interfering with the modernized
command group.
"""

from __future__ import annotations

# No imports, no executable code, no command registration.
# This module must remain inert by design.

__all__ = []
