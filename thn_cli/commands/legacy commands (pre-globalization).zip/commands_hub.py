"""
THN Hub / Nexus Command Group
-----------------------------

Commands:

    thn hub status
    thn hub sync

Provides status reporting and placeholder sync actions for the
future THN Hub / Nexus integration layer.
"""

from __future__ import annotations

import argparse
import json

from thn_cli.hub.hub_status import get_hub_status
from thn_cli.hub.hub_sync import perform_hub_sync


# ---------------------------------------------------------------------------
# Command Handlers
# ---------------------------------------------------------------------------

def run_hub_status(args: argparse.Namespace) -> int:
    status = get_hub_status()
    print("\nTHN Hub Status\n")
    print(json.dumps(status, indent=4))
    print()
    return 0


def run_hub_sync(args: argparse.Namespace) -> int:
    result = perform_hub_sync()
    print("\nTHN Hub Sync\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Command Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Register:

        thn hub ...
    """
    parser = subparsers.add_parser(
        "hub",
        help="THN Hub / Nexus integration commands.",
        description="Inspect or interact with the THN Hub (future expansion).",
    )

    sub = parser.add_subparsers(dest="hub_command", required=True)

    # thn hub status
    p_status = sub.add_parser(
        "status",
        help="Show THN Hub subsystem status.",
        description="Return connection state, config details, and basic Hub diagnostics.",
    )
    p_status.set_defaults(func=run_hub_status)

    # thn hub sync
    p_sync = sub.add_parser(
        "sync",
        help="Perform THN Hub sync (placeholder).",
        description="Trigger an outbound sync to the THN Hub (scaffolding only).",
    )
    p_sync.set_defaults(func=run_hub_sync)

    # If user runs only `thn hub`, show help
    parser.set_defaults(func=lambda args: parser.print_help())
