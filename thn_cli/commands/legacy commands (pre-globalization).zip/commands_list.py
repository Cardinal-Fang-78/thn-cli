"""
THN Path Listing Command
------------------------

Provides:

    thn list

Displays all resolved THN paths as defined by the pathing subsystem.
"""

from __future__ import annotations

import json
import argparse

from thn_cli.pathing import get_thn_paths


# ---------------------------------------------------------------------------
# Command Implementation
# ---------------------------------------------------------------------------

def run_list_paths(_: argparse.Namespace) -> int:
    paths = get_thn_paths()

    print("\nTHN Paths\n")
    print(json.dumps(paths, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Parser Registration
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "list",
        help="List THN system paths.",
        description="Display all resolved THN directories from the pathing subsystem.",
    )

    parser.set_defaults(func=run_list_paths)
