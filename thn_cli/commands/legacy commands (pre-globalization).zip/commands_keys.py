"""
THN Keys Management
-------------------

Manages Ed25519 signing identities used for Sync V2:

    thn keys generate   [--force]
    thn keys show
    thn keys rotate
    thn keys trust <public_key_hex>

Includes persistent keypair handling + trusted public-key store.
"""

from __future__ import annotations

import argparse
from typing import List

from thn_cli.syncv2.keys import (
    create_signing_key,
    load_signing_key,
    get_trusted_pubkeys,
    add_trusted_public_key,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _print(msg: str) -> None:
    print(msg)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def run_keys_generate(args: argparse.Namespace) -> int:
    force = bool(args.force)

    try:
        _, pub_hex = create_signing_key(overwrite=force)
    except RuntimeError as exc:
        _print(str(exc))
        return 1

    print("\nTHN Keys: Generate\n")
    _print("New Ed25519 signing key generated.")
    _print(f"Public key (hex): {pub_hex}")
    _print("This key has been added to the trusted_pubkeys store.\n")
    return 0


def run_keys_show(_: argparse.Namespace) -> int:
    try:
        _, current_pub = load_signing_key()
    except RuntimeError as exc:
        current_pub = None
        print("\nTHN Keys: Show\n")
        _print(str(exc))
        print()
    else:
        print("\nTHN Keys: Show\n")
        _print("Current Ed25519 public key:")
        _print(current_pub)
        print()

    trusted: List[str] = get_trusted_pubkeys()
    _print("Trusted public keys:")
    if not trusted:
        _print("  (none)")
    else:
        for idx, key in enumerate(trusted, start=1):
            prefix = "  *" if key == current_pub else "   "
            _print(f"{prefix} [{idx}] {key}")
    print()

    return 0


def run_keys_rotate(_: argparse.Namespace) -> int:
    try:
        _, old_pub = load_signing_key()
    except RuntimeError:
        old_pub = None

    try:
        _, new_pub = create_signing_key(overwrite=True)
    except RuntimeError as exc:
        print("\nTHN Keys: Rotate\n")
        _print(str(exc))
        print()
        return 1

    print("\nTHN Keys: Rotate\n")
    _print("Signing key rotated.")
    _print(f"New public key (hex): {new_pub}")
    if old_pub:
        _print(f"Previous public key retains trust: {old_pub}")
    print()

    return 0


def run_keys_trust(args: argparse.Namespace) -> int:
    pub_hex = args.public_key.strip()
    print("\nTHN Keys: Trust\n")

    if not pub_hex:
        _print("Error: No public key provided.\n")
        return 1

    add_trusted_public_key(pub_hex)
    _print("Public key added to trusted_pubkeys:")
    _print(pub_hex)
    print()

    return 0


# ---------------------------------------------------------------------------
# Parser Registration
# ---------------------------------------------------------------------------

def add_subparser(root_subparsers: argparse._SubParsersAction) -> None:
    """
    Register:
        thn keys generate
        thn keys show
        thn keys rotate
        thn keys trust <public_key_hex>
    """

    parser = root_subparsers.add_parser(
        "keys",
        help="Manage THN Ed25519 signing keys and trusted public keys.",
        description=(
            "Generate, show, rotate, and trust Ed25519 identities used by "
            "the Sync V2 signature pipeline."
        ),
    )

    sub = parser.add_subparsers(
        dest="keys_command",
        title="keys commands",
    )

    # --- generate ---
    p_gen = sub.add_parser(
        "generate",
        help="Generate a new signing key (fails unless --force is given).",
    )
    p_gen.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing signing key.",
    )
    p_gen.set_defaults(func=run_keys_generate)

    # --- show ---
    p_show = sub.add_parser(
        "show",
        help="Display current signing key and trusted keys.",
    )
    p_show.set_defaults(func=run_keys_show)

    # --- rotate ---
    p_rot = sub.add_parser(
        "rotate",
        help="Rotate signing key; old public keys remain trusted.",
    )
    p_rot.set_defaults(func=run_keys_rotate)

    # --- trust ---
    p_trust = sub.add_parser(
        "trust",
        help="Add an external public key to the trusted store.",
    )
    p_trust.add_argument(
        "public_key",
        help="Hex-encoded public key to trust.",
    )
    p_trust.set_defaults(func=run_keys_trust)

    # Default
    parser.set_defaults(func=lambda args: parser.print_help())
