# thn_cli/commands_sync_web.py

"""
THN Sync Web wrapper on top of Sync V2 engine + target abstraction.

Command:

    thn sync web --input <folder-or-file> [--dry-run | --apply]

Workflow:

1. Accept folder/file input.
2. ZIP into a temporary payload ZIP.
3. Build a Sync V2 envelope ZIP.
4. Load + inspect the envelope.
5. Apply (or simulate apply) via WebSyncTarget.
"""

from __future__ import annotations

import argparse
import os
import tempfile
import zipfile

from thn_cli.syncv2.make_test import make_test_envelope
from thn_cli.syncv2.envelope import load_envelope_from_file, inspect_envelope
from thn_cli.syncv2.engine import apply_envelope_v2
from thn_cli.syncv2.targets.web import WebSyncTarget


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _zip_input(input_path: str) -> str:
    """
    ZIP a folder or a single file into a temporary ZIP.
    Returns the path to the newly created ZIP.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input path does not exist: {input_path}")

    fd, temp_zip = tempfile.mkstemp(suffix=".zip")
    os.close(fd)

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(input_path):
            for root, _, files in os.walk(input_path):
                for name in files:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, input_path)
                    z.write(full, rel)
        else:
            z.write(input_path, os.path.basename(input_path))

    return temp_zip


# ---------------------------------------------------------------------
# Command Handler
# ---------------------------------------------------------------------

def run_sync_web(args: argparse.Namespace) -> None:
    """
    Entry point for `thn sync web`.
    """
    input_path = args.input

    print()
    print("==========================================")
    print("     THN SYNC WEB (V1) via SYNC V2")
    print("==========================================")
    print()
    print(f"Input path: {input_path}\n")

    # Step 1: ZIP input
    print("Step 1: Zipping input folder/file...")
    raw_zip = _zip_input(input_path)
    print(f"\nCreated raw ZIP:\n  {raw_zip}\n")

    # Step 2: Create envelope
    print("Step 2: Creating V2 envelope...")
    result = make_test_envelope(raw_zip)

    envelope_zip = result.get("envelope_zip")
    if not envelope_zip:
        raise RuntimeError("make_test_envelope did not return 'envelope_zip'")

    print(f"\nGenerated envelope ZIP:\n  {envelope_zip}\n")

    # Step 3: Load envelope
    print("Step 3: Loading envelope...")
    env = load_envelope_from_file(envelope_zip)
    print()

    # Step 4: Inspect envelope
    print("Step 4: Inspecting envelope...\n")
    info_json = inspect_envelope(env)
    print(info_json)
    print()

    # Step 5: Apply logic
    dry_run = bool(args.dry_run)
    explicit_apply = bool(args.apply)

    if not dry_run and not explicit_apply:
        print("No --dry-run or --apply flag given; defaulting to DRY RUN.\n")
        dry_run = True

    print("Step 5: Applying envelope...")
    print(f"  Dry run : {dry_run}\n")

    target = WebSyncTarget()
    result_json = apply_envelope_v2(env, target, dry_run=dry_run)

    print(result_json)
    print("\nTHN Sync Web workflow complete.\n")


# ---------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------

def add_subparser(sync_subparsers: argparse._SubParsersAction) -> None:
    """
    Attach the 'web' subcommand to the 'sync' command group:

        thn sync web --input <folder-or-file> [--dry-run | --apply]
    """
    parser = sync_subparsers.add_parser(
        "web",
        help="Run legacy THN Sync Web via the Sync V2 engine.",
        description=(
            "Zips a folder or file, builds a V2 envelope, inspects it, and "
            "applies it to the Web sync directory. Defaults to dry run unless "
            "--apply is provided."
        ),
    )

    parser.add_argument(
        "--input",
        "--in",     # legacy alias
        "-i",
        dest="input",
        required=True,
        help="Folder or file to sync (automatically zipped).",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Inspect envelope + simulate apply without modifying files.",
    )

    parser.add_argument(
        "--apply",
        action="store_true",
        help="Perform a live apply (write files).",
    )

    parser.set_defaults(func=run_sync_web)
