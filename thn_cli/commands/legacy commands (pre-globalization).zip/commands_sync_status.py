# thn_cli/commands_sync_status.py

"""
THN Sync Status commands.

Provides:

    thn sync-status history   [--target web|cli|docs|...] [--limit N]
    thn sync-status last      [--target web|cli|docs|...]
    thn sync-status show      <id>
    thn sync-status rollback  <id>

Rollback restores the backup ZIP associated with a historical entry,
writes it back to its destination path, and records a new rollback entry.
"""

from __future__ import annotations

import argparse
from typing import Optional, Dict, Any

from thn_cli.syncv2 import status_db
from thn_cli.syncv2.utils.fs_ops import restore_backup_zip


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _print_header(title: str) -> None:
    print()
    print("==========================================")
    print(f"   {title}")
    print("==========================================")
    print()


def _print_row(row: Dict[str, Any]) -> None:
    print(
        f"[{row['id']}] {row['ts']}  "
        f"target={row['target']}  mode={row['mode']}  "
        f"op={row['operation']}  success={bool(row['success'])}  "
        f"dry_run={bool(row['dry_run'])}"
    )
    print(f"    destination : {row.get('destination')}")
    print(f"    file_count  : {row.get('file_count')}")
    print(f"    total_size  : {row.get('total_size')}")
    print(f"    manifest    : {row.get('manifest_hash')}")
    print(f"    backup_zip  : {row.get('backup_zip')}")
    print(f"    envelope    : {row.get('envelope_path')}")
    print(f"    source_root : {row.get('source_root')}")

    notes = row.get("notes")
    if notes:
        print(f"    notes       : {notes}")

    print()


# ---------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------

def run_history(args: argparse.Namespace) -> None:
    target = args.target
    limit = args.limit

    _print_header("THN Sync Status : History")

    entries = status_db.get_history(target=target, limit=limit)
    if not entries:
        print("No history entries found.")
        return

    for row in entries:
        _print_row(row)


def run_last(args: argparse.Namespace) -> None:
    target = args.target

    _print_header("THN Sync Status : Last Entry")

    row = status_db.get_last(target=target)
    if row is None:
        print("No entries found.")
        return

    _print_row(row)


def run_show(args: argparse.Namespace) -> None:
    entry_id = int(args.id)

    _print_header(f"THN Sync Status : Show Entry {entry_id}")

    row = status_db.get_entry_by_id(entry_id)
    if row is None:
        print(f"No entry found with id {entry_id}.")
        return

    _print_row(row)


def run_rollback(args: argparse.Namespace) -> None:
    entry_id = int(args.id)

    _print_header(f"THN Sync Status : Rollback from Entry {entry_id}")

    row = status_db.get_entry_by_id(entry_id)
    if row is None:
        print(f"No entry found with id {entry_id}.")
        return

    backup_zip = row.get("backup_zip")
    destination = row.get("destination")
    target = row.get("target")

    if not backup_zip:
        print("This entry has no backup_zip associated; cannot rollback.")
        return

    if not destination:
        print("This entry has no destination path recorded; cannot rollback.")
        return

    print("Restoring backup:")
    print(f"  backup_zip  : {backup_zip}")
    print(f"  destination : {destination}")
    print()

    try:
        restore_backup_zip(backup_zip, destination)
    except Exception as exc:
        print(f"Rollback failed: {exc}")
        return

    print("Rollback completed successfully.")
    print("Recording rollback event in Sync Status DB.\n")

    status_db.record_apply(
        target=target or "unknown",
        mode="rollback",
        operation="rollback",
        dry_run=False,
        success=True,
        manifest_hash=row.get("manifest_hash"),
        envelope_path=None,
        source_root=row.get("source_root"),
        file_count=row.get("file_count"),
        total_size=row.get("total_size"),
        backup_zip=backup_zip,
        destination=destination,
        notes={"rolled_back_from_id": entry_id},
    )


# ---------------------------------------------------------------------
# Subparser registration
# ---------------------------------------------------------------------

def add_subparser(root_subparsers: argparse._SubParsersAction) -> None:
    """
    Register the sync-status command group.
    """

    parser = root_subparsers.add_parser(
        "sync-status",
        help="View and manage THN Sync V2 status history.",
        description=(
            "Show sync history, inspect entries, and perform rollback using "
            "historical backup ZIPs."
        ),
    )

    sub = parser.add_subparsers(
        title="sync-status commands",
        dest="sync_status_command",
        required=True,
    )

    # history
    p_hist = sub.add_parser(
        "history",
        help="List recent sync operations.",
    )
    p_hist.add_argument(
        "--target",
        help="Filter by target (e.g., web, cli, docs).",
    )
    p_hist.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Maximum number of entries to show (default: 50).",
    )
    p_hist.set_defaults(func=run_history)

    # last
    p_last = sub.add_parser(
        "last",
        help="Show the most recent sync operation.",
    )
    p_last.add_argument(
        "--target",
        help="Filter by target (e.g., web, cli, docs).",
    )
    p_last.set_defaults(func=run_last)

    # show
    p_show = sub.add_parser(
        "show",
        help="Show detailed information about a specific entry.",
    )
    p_show.add_argument("id", help="Entry id to show.")
    p_show.set_defaults(func=run_show)

    # rollback
    p_rb = sub.add_parser(
        "rollback",
        help="Rollback to the backup created by a specific entry id.",
    )
    p_rb.add_argument("id", help="Entry id whose backup should be restored.")
    p_rb.set_defaults(func=run_rollback)
