"""
THN Routing Command Group
-------------------------

Provides commands for inspecting and testing the THN routing engine.

Commands:

    thn routing show
    thn routing test [--file <zip>] [--tag <tag>]
"""

from __future__ import annotations

import argparse
import json
import os

from thn_cli.routing.engine import auto_route
from thn_cli.routing.rules import load_routing_rules
from thn_cli.pathing import get_thn_paths


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

def run_routing_show(_: argparse.Namespace) -> int:
    rules = load_routing_rules()

    print("\nTHN Routing Configuration\n")
    print(json.dumps(rules, indent=4))
    print()
    return 0


def run_routing_test(args: argparse.Namespace) -> int:
    paths = get_thn_paths()

    tag = args.tag or "test"
    payload_path = args.file

    zip_bytes = b""
    envelope = None

    # Validate file path if given
    if payload_path:
        if not os.path.isfile(payload_path):
            print("\nError: The file specified with --file does not exist.\n")
            print(f"  Provided path: {payload_path}")
            print(f"  Working directory: {os.getcwd()}\n")
            print("Please provide either:")
            print("  • A full absolute path")
            print("  • Or place the ZIP file in the current working directory.\n")
            return 1

        try:
            with open(payload_path, "rb") as f:
                zip_bytes = f.read()
        except Exception as exc:
            print(f"\nError: Failed to read '{payload_path}': {exc}\n")
            return 1

    # Perform routing test
    result = auto_route(envelope, tag, zip_bytes, paths)

    print("\nRouting Test Result\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "routing",
        help="Routing utilities for THN.",
        description="THN Routing Engine tools.",
    )

    routing_sub = parser.add_subparsers(dest="routing_cmd", required=True)

    # thn routing show
    p_show = routing_sub.add_parser(
        "show",
        help="Show routing configuration.",
    )
    p_show.set_defaults(func=run_routing_show)

    # thn routing test
    p_test = routing_sub.add_parser(
        "test",
        help="Test routing rules using an optional payload ZIP.",
    )
    p_test.add_argument(
        "--file",
        help="Path to ZIP payload to test routing behavior.",
        required=False,
    )
    p_test.add_argument(
        "--tag",
        help="Tag to evaluate. Default: 'test'.",
        required=False,
    )
    p_test.set_defaults(func=run_routing_test)

    # default: show help
    parser.set_defaults(func=lambda args: parser.print_help())
