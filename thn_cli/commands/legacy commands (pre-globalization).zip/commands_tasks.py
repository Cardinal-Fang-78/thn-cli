# thn_cli/commands_tasks.py

"""
THN Tasks command group.

Provides:

    thn tasks list
    thn tasks add <name> <cmd> <schedule>
    thn tasks remove <name>
    thn tasks run <name>

This is a lightweight task scheduler interface used for
internal THN automation (placeholder implementation).
"""

from __future__ import annotations

import argparse
import json

from thn_cli.tasks.scheduler import (
    list_tasks,
    add_task,
    remove_task,
    run_task,
)


# ---------------------------------------------------------------------
# Command Handlers
# ---------------------------------------------------------------------

def run_tasks_list(args: argparse.Namespace) -> int:
    tasks = list_tasks()

    if not tasks:
        print("\nNo tasks registered.\n")
        return 0

    print("\nTHN Tasks:\n")
    for t in tasks:
        status = "enabled" if t.get("enabled") else "disabled"
        print(f"- {t['name']} [{status}]")
        print(f"    Command : {t['command']}")
        print(f"    Schedule: {t['schedule']}\n")

    return 0


def run_tasks_add(args: argparse.Namespace) -> int:
    ok = add_task(args.name, args.command, args.schedule)

    if not ok:
        print(f"\nTask '{args.name}' already exists.\n")
        return 1

    print(f"\nTask '{args.name}' added.\n")
    return 0


def run_tasks_remove(args: argparse.Namespace) -> int:
    ok = remove_task(args.name)

    if not ok:
        print(f"\nTask '{args.name}' not found.\n")
        return 1

    print(f"\nTask '{args.name}' removed.\n")
    return 0


def run_tasks_run(args: argparse.Namespace) -> int:
    result = run_task(args.name)

    print("\nTask Execution\n")
    print(json.dumps(result, indent=4))
    print()
    return 0


# ---------------------------------------------------------------------
# Subparser Registration
# ---------------------------------------------------------------------

def add_subparser(subparsers: argparse._SubParsersAction) -> None:
    """
    Register:

        thn tasks ...
    """
    parser = subparsers.add_parser(
        "tasks",
        help="Manage scheduled tasks (placeholder).",
        description="List, add, remove, and run THN tasks.",
    )

    sub = parser.add_subparsers(dest="tasks_cmd", required=True)

    # list
    p_list = sub.add_parser("list", help="List all tasks.")
    p_list.set_defaults(func=run_tasks_list)

    # add
    p_add = sub.add_parser("add", help="Add a new task.")
    p_add.add_argument("name")
    p_add.add_argument("command")
    p_add.add_argument("schedule")
    p_add.set_defaults(func=run_tasks_add)

    # remove
    p_remove = sub.add_parser("remove", help="Remove a task.")
    p_remove.add_argument("name")
    p_remove.set_defaults(func=run_tasks_remove)

    # run
    p_run = sub.add_parser("run", help="Run a task immediately.")
    p_run.add_argument("name")
    p_run.set_defaults(func=run_tasks_run)

    parser.set_defaults(func=lambda args: parser.print_help())
